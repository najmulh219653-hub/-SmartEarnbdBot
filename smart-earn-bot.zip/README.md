
# Smart Earn Bot (Cloudflare Workers Modular)

## Setup

1. Install Wrangler:
   ```bash
   npm install -g wrangler
   ```
2. Login to Cloudflare:
   ```bash
   wrangler login
   ```
3. Deploy:
   ```bash
   wrangler publish
   ```

## KV Setup
- Create a KV namespace `BOT_USERS_DATA`
- Add binding in Worker: `USERS_KV`

## Env Variables
Set these in wrangler.toml or dashboard:
- TELEGRAM_BOT_TOKEN
- ADMIN_USER_ID
- ADSTERRA_DIRECT_LINK
- TASK_LANDING_PAGE
- CHANNEL_USERNAME
- CHANNEL_INVITE_LINK

