
import { Env, UserData } from '../index';

export async function getUserData(env: Env, userId: number): Promise<UserData> {
  const key = `user:${userId}`;
  const data = await env.USERS_KV.get(key, 'json');
  if(data) return data as UserData;
  return { points:0, last_claim_date:null, referrer_id:null, username:'Guest' };
}

export async function saveUserData(env: Env, userId: number, data: UserData): Promise<void> {
  const key = `user:${userId}`;
  await env.USERS_KV.put(key, JSON.stringify(data));
}
