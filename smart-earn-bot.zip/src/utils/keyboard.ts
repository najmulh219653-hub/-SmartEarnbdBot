
import { Env } from '../index';

export function getKeyboard(points:number, env:Env) {
  return { inline_keyboard: [
    [{ text: "💰 দৈনিক বোনাস ক্লেম করুন", callback_data: 'daily_reward' }],
    [{ text: "📰 ট্র্যাক ১: আজকের খবর দেখুন", url: env.TASK_LANDING_PAGE }],
    [{ text: "🔗 ট্র্যাক ২: অ্যাপ লিঙ্ক দেখুন", url: env.TASK_LANDING_PAGE }],
    [{ text: "🧠 ট্র্যাক ৩: কুইজ খেলুন", url: env.TASK_LANDING_PAGE }],
    [{ text: `📊 আমার ব্যালেন্স: ${points} পয়েন্ট`, callback_data: 'my_account' }],
    [{ text: "💸 উইথড্রয়াল রিকোয়েস্ট", callback_data: 'withdraw_request' }],
  ]};
}
