
import { Env } from '../index';

export async function sendMessage(env: Env, chatId: number, text: string, replyMarkup?: object, parseMode: string = 'Markdown') {
  const url = `https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`;
  await fetch(url, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({chat_id: chatId, text, reply_markup: replyMarkup, parse_mode: parseMode}) });
}
