
export interface Env {
  TELEGRAM_BOT_TOKEN: string;
  ADMIN_USER_ID: string;
  ADSTERRA_DIRECT_LINK: string;
  TASK_LANDING_PAGE: string;
  CHANNEL_USERNAME: string;
  CHANNEL_INVITE_LINK: string;
  USERS_KV: KVNamespace;
}

export interface UserData {
  points: number;
  last_claim_date: string | null;
  referrer_id: number | null;
  username: string;
}
